class SignupViewModel {
  String name = "";
  String email = "";
  String password = "";
  bool busy = false;
}
